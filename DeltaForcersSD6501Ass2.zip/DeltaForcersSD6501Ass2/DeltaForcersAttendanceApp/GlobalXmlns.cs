[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "DeltaForcersAttendanceApp")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "DeltaForcersAttendanceApp.Pages")]
