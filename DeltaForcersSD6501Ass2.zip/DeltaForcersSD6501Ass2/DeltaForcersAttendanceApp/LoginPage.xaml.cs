namespace DeltaForcersAttendanceApp;

public partial class LoginPage : ContentPage
{
    public LoginPage()
    {
        InitializeComponent();
    }

    private async void LoginButton_Clicked(object? sender, EventArgs e)
    {
        string user = UsernameEntry.Text ?? "";
        string pass = PasswordEntry.Text ?? "";

        if (user == "123456" && pass == "123456")
        {
            await Navigation.PushAsync(new MainPage());
        }
        else
        {
            await DisplayAlert("Login Failed", "Incorrect Student ID or Password.\nCorrect: 123456", "OK");
        }
    }
}