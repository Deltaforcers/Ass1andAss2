namespace DeltaForcersAttendanceApp;

public partial class HistoryPage : ContentPage
{
    public HistoryPage()
    {
        InitializeComponent();
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        
        var records = FileService.LoadRecords();
        HistoryListView.ItemsSource = records;
    }
}