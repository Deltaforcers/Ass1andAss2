﻿using System.Text.Json;

namespace DeltaForcersAttendanceApp;

public static class FileService
{
    // 保存签到记录
    public static void SaveRecord(List<AttendanceRecord> list)
    {
        string path = Path.Combine(FileSystem.AppDataDirectory, "history.json");
        string json = JsonSerializer.Serialize(list);
        File.WriteAllText(path, json);
    }

    // 读取签到记录
    public static List<AttendanceRecord> LoadRecords()
    {
        string path = Path.Combine(FileSystem.AppDataDirectory, "history.json");
        if (!File.Exists(path)) return new List<AttendanceRecord>();

        string json = File.ReadAllText(path);
        return JsonSerializer.Deserialize<List<AttendanceRecord>>(json) ?? new List<AttendanceRecord>();
    }
}