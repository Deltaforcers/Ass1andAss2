﻿namespace DeltaForcersAttendanceApp;

public class AttendanceRecord
{
    public string CourseName { get; set; } = "";
    public string CheckInTime { get; set; } = "";
    public string Location { get; set; } = "";
    public string Status { get; set; } = "";
}