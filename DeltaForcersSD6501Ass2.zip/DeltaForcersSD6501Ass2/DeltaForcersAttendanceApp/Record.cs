﻿namespace DeltaForcersAttendanceApp
{
    public class Record
    {
        public string DateTime { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
    }
}