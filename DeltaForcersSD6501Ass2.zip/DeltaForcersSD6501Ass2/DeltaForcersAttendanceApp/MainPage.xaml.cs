﻿namespace DeltaForcersAttendanceApp;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }

    private async void GoToCheckIn(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new CheckInPage());
    }

    
    private async void GoToHistory(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new HistoryPage());
    }
}