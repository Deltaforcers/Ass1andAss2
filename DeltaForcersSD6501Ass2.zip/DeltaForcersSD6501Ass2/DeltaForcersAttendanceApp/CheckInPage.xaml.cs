namespace DeltaForcersAttendanceApp;

public partial class CheckInPage : ContentPage
{
    public CheckInPage()
    {
        InitializeComponent();
        GetCurrentGPSLocation();
    }

    private string _currentLocation = "";

    private async void GetCurrentGPSLocation()
    {
        try
        {
            var location = await Geolocation.GetLastKnownLocationAsync();
            if (location == null)
            {
                location = await Geolocation.GetLocationAsync(new GeolocationRequest
                {
                    DesiredAccuracy = GeolocationAccuracy.Medium,
                    Timeout = TimeSpan.FromSeconds(10)
                });
            }

            if (location != null)
            {
                _currentLocation = $"Lat {location.Latitude:F3}, Lng {location.Longitude:F3}";
                LocationLabel.Text = _currentLocation;
            }
            else
            {
                LocationLabel.Text = "GPS unavailable";
            }
        }
        catch
        {
            LocationLabel.Text = "GPS error";
        }
    }

    // ���ǩ�� �� �����¼
    private async void OnCheckInClicked(object? sender, EventArgs e)
    {
        // 1. ��ȡ������ʷ
        var records = FileService.LoadRecords();

        // 2. �����¼�¼
        records.Add(new AttendanceRecord
        {
            CourseName = "SD6501 .NET MAUI",
            CheckInTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm"),
            Location = _currentLocation,
            Status = "Checked In"
        });

        // 3. ���浽�ļ�
        FileService.SaveRecord(records);

        await DisplayAlert("Success", "You have checked in and saved to history", "OK");
    }
}