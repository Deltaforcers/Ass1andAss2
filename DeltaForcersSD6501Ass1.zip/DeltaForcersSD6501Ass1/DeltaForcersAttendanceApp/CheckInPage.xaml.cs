namespace DeltaForcersAttendanceApp;

public partial class CheckInPage : ContentPage
{
	public CheckInPage()
	{
		InitializeComponent();
	}
}